﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_3;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            OneDimArr arr1 = new OneDimArr(10);
            OneDimArr arr2 = new OneDimArr(4);
            OneDimArr arrExpected = new OneDimArr(14);
            OneDimArr arrResult;

            arr1.Enter(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
            arr2.Enter(new double[] { -2, -4, -5, -6 });
            arrExpected.Enter(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -2, -4, -5, -6 });

            arrResult = arr1 + arr2;

            for (int i = 0; i < arrResult.GetLength(); i++)
            {
                Assert.AreEqual(arrExpected[i], arrResult[i]);
            }
        }

        [TestMethod]
        public void TestMethod2()
        {
            OneDimArr arr1 = new OneDimArr(4);
            OneDimArr arr2 = new OneDimArr(4);
            double sum;

            arr1.Enter(new double[] { 1, 2, 3, 4 });
            arr2.Enter(new double[] { 6, 7, 8, 9 });

            sum = arr2.CalcSum() + arr1.CalcSum();

            Assert.AreEqual(sum, 40);
        }

        [TestMethod]
        public void TestMethod3()
        {
            OneDimArr arr1 = new OneDimArr(4);
            OneDimArr arr2 = new OneDimArr(4);
            double sum;

            arr1.Enter(new double[] { 1, 2, 3, 4 });
            arr2.Enter(new double[] { 6, 7, 8, 9 });

            sum = arr2.CalcSum(1, 3) + arr1.CalcSum(1, 3);

            Assert.AreEqual(sum, 22);
        }

        [TestMethod]
        public void TestMethod4()
        {
            OneDimArr arr1 = new OneDimArr(8);
            OneDimArr arr2 = new OneDimArr(4);
            OneDimArr arrResult;

            arr1.Enter(new double[] { 1, 2, 3, 4, 5, 6, 7, 8 });
            arr2.Enter(new double[] { 6, 7, 8, 9 });

            arrResult = arr1 + arr2;

            Assert.AreEqual(arrResult.GetLength(), 12);
        }

        [TestMethod]
        public void TestMethod5()
        {
            OneDimArr arr1 = new OneDimArr(8);
            OneDimArr arr2 = new OneDimArr(4);
            OneDimArr arrResult;

            arr1.Enter(new double[] { 1, 2, 3, 4, 5, 6, 7, 8 });
            arr2.Enter(new double[] { -3, 7, 8, 9 });

            arrResult = arr1 + arr2;

            Assert.AreEqual(arrResult[8], -3);
        }
    }
}
