﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    /// <summary>
    /// Класс, представляющий одномерный массив
    /// </summary>
    public class OneDimArr
    {
        /// <summary>
        /// Свойства объекта
        /// </summary>
        /// <param name="_elements">Элементы одномерного массива</param>
        /// <param name="_length">Количество элементо массива</param>
        private double[] _elements;
        private int _length;

        public OneDimArr(int length)
        {
            _length = length;
            this._elements = new double[_length];
        }

        public OneDimArr()
        {
            _length = 0;
        }

        /// <summary>
        /// Метод для получения длины массива
        /// </summary>
        /// <returns>Возвращает длину массива</returns>
        public int GetLength()
        {
            return this._length;
        }

        /// <summary>
        /// Свойство-индексатор для обращения к элементам массива
        /// </summary>
        /// <param name="index">Номер элемента, к которому мы хотим обратиться</param>
        /// <returns>Элемент с номером index</returns>
        public double this[int index]
        {
            get => _elements[index];
            set => _elements[index] = value;
        }

        /// <summary>
        /// Вводит значения элемента массива.
        /// Так как заранее неизвестно, откуда именно будут введены элементы, то
        /// мы просто передаем элемнты, которые ввели из некоторого источника.
        /// </summary>
        /// <param name="enteredVals">Элементы, которые мы ввели</param>
        public void Enter(params double[] enteredVals)
        {
            for (int i = 0; i < enteredVals.Length; i++)
            {
                this[i] = enteredVals[i];
            }
        }

        /// <summary>
        /// Печатает элементы массива.
        /// Так как заранее неизвестно, куда именно они будут выводиться, то
        /// мы просто возвращаем элементы для дальнейшего вывода
        /// </summary>
        /// <returns>Элементы массива</returns>
        public double[] Print()
        {
            return _elements;
        }

        /// <summary>
        /// Считаем сумму элементов с указанными индексами
        /// </summary>
        /// <param name="indexes">Элементы с этими индексами мы будет суммировать</param>
        /// <returns>Сумма элементов с указанными индексами</returns>
        public double CalcSum(params int[] indexes)
        {
            double sum = 0;

            for (int i = 0; i < indexes.Length; i++)
            {
                sum += this[indexes[i]];
            }

            return sum;
        }

        /// <summary>
        /// Считает сумму всех элементов массива
        /// </summary>
        /// <returns>Сумма элементов массива</returns>
        public double CalcSum()
        {
            double sum = 0;

            for (int i = 0; i < _length; i++)
            {
                sum += this[i];
            }

            return sum;
        }

        /// <summary>
        /// Перезагрузка оператора сложения.
        /// При сложении создается новый объект, элементы которого есть элементы 
        /// массивов arr1 и arr2, притом, что arr2 добавлен в конец arr1.
        /// </summary>
        /// <param name="arr1">Первый массив</param>
        /// <param name="arr2">Второй массив</param>
        /// <returns>Новый массив, являющийся результатом суммы двух других</returns>
        public static OneDimArr operator +(OneDimArr arr1, OneDimArr arr2)
        {
            OneDimArr arrResult = new OneDimArr(arr1.GetLength() + arr2.GetLength());

            int i, j, k;

            for (i = 0, k = 0; i < arr1.GetLength(); i++, k++)
            {
                arrResult[k] = arr1[i];
            }

            for (i = 0, j = k; i < arr2.GetLength(); i++, j++)
            {
                arrResult[j] = arr2[i];
            }

            return arrResult;
        }

        /// <summary>
        /// Метод, проверяющий, все ли элементы равны 0.
        /// False, если хотя бы один не равен 0
        /// True, если все равны 0
        /// </summary>
        /// <returns>Равны ли все элементы 0</returns>
        public bool IsAllElementsZero()
        {
            bool areAllEmentsZero = true;

            for (int i = 0; i < this.GetLength() && areAllEmentsZero; i++)
            {
                if (this[i] != 0)
                {
                    areAllEmentsZero = false;
                }
            }

            return areAllEmentsZero;
        }

        /// <summary>
        /// Перезагрузка оператора true.
        /// Если все элементы массива равны 0, то вернет false;
        /// </summary>
        /// <param name="arr1">Массив, на котором вызывается оператор</param>
        /// <returns>Преведение массива к логическому значению</returns>
        public static bool operator true(OneDimArr arr1)
        {
            return !arr1.IsAllElementsZero();
        }

        /// <summary>
        /// Перезагрузка оператора false.
        /// Если все элементы массива равны 0, то вернет true;
        /// </summary>
        /// <param name="arr1">Массив, на котором вызывается оператор</param>
        /// <returns>Преведение массива к логическому значению</returns>
        public static bool operator false(OneDimArr arr1)
        {
            return arr1.IsAllElementsZero();
        }

    }
