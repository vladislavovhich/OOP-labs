﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab_3;

namespace Lab_3_ConsoleInterface
{
    class Program
    {
        static void Main(string[] args)
        {
            OneDimArr A = new OneDimArr(15);
            OneDimArr B = new OneDimArr(15);
            OneDimArr C = new OneDimArr(15);

            A.Enter(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
            B.Enter(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
            C.Enter(new double[] { 0, 2, 0, 4, 0, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });


            PrintViaKeyboard(A);
            PrintViaKeyboard(B);
            PrintViaKeyboard(C);

            double sumOfAllArrays = A.CalcSum() + B.CalcSum() + C.CalcSum();
            double sumOfAC = A.CalcSum(2, 5, 6, 8, 12) + C.CalcSum(2, 5, 6, 8, 12);
            double sumOfAB = A.CalcSum() + B.CalcSum();
            double sumOfOdd = 0;

            for (int i = 0; i < B.GetLength(); i += 2)
            {
                sumOfOdd += B[i];
            }

            if (!A.IsAllElementsZero() && !B.IsAllElementsZero())
            {
                for (int i = 0; i < C.GetLength(); i++)
                {
                    if (C[i] != 0)
                    {
                        C[i] = sumOfAB;
                    }
                }
            }

            Console.WriteLine("Сумма всех элементов массива: {0}", sumOfAllArrays);
            Console.WriteLine("Сумма элементов массива B c четными индексами: {0}", sumOfOdd);
            Console.WriteLine("Сумма всех элементов массива А и Б с индексами 2, 5, 6, 8, 12: {0}", sumOfAC);
            Console.WriteLine("Массив С, после того, как все ненулевые элементы заменили на сумму А и Б:");

            for (int i = 0; i < C.GetLength(); i++)
                Console.WriteLine(C[i]);

            Console.ReadKey();
        }

        public static OneDimArr EnterViaKeyboard()
        {
            OneDimArr arr1;

            Console.Write("Введите длину A: ");

            int length = Convert.ToInt32(Console.ReadLine());

            arr1 = new OneDimArr(length);

            for (int i = 0; i < length; i++)
            {
                arr1[i] = Convert.ToDouble(Console.ReadLine());
            }

            return arr1;
        }

        public static void PrintViaKeyboard(OneDimArr arr)
        {
            for (int i = 0; i < arr.GetLength(); i++)
            {
                Console.WriteLine(arr[i]);
            }

            Console.WriteLine("");
        }
    }
}
