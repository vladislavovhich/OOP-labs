﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using lab8;

namespace lab8_interface
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Human> _humans = Program.ReadHumanFromFile();
        public MainWindow()
        {
            InitializeComponent();

            ShowAllHumans(_humans);
        }

        private void ShowAllHumans(List<Human> humans)
        {
            HumansListBox.Items.Clear();

            foreach (Human human in humans)
            {
                if (human.Age <= 25)
                {
                    HumansListBox.Items.Add(new ListBoxItem() { Content = human.Information(), Foreground = Brushes.Green });
                }
                else
                {   
                    HumansListBox.Items.Add(new ListBoxItem() { Content = human.Information(), Foreground = Brushes.Black });
                }
            }
         
        }

        private void ShowLoadBtn_Click(object sender, RoutedEventArgs e)
        {
            double load = 0;
            string subject = LessonType.Text;

            Teacher teacher;

            int amount = 0;

            foreach (Human human in _humans)
            {
                if (human is Teacher)
                {
                    teacher = human as Teacher;

                    load += teacher[subject];
                   
                    amount++;
                }
            }

            load = Math.Floor(load / amount);
         
            HumansListBox.Items.Clear();

            HumansListBox.Items.Add("Нагрузка по предмету " + subject + " равна: " + load.ToString());
      
        }

        private void ShowAllHumansBtn_Click(object sender, RoutedEventArgs e)
        {
            _humans.Sort(new HumanSurnameComparator());
            ShowAllHumans(_humans);
        }

        private void ShowWorstStudentsBtn_Click(object sender, RoutedEventArgs e)
        {
            List<Human> humans = new List<Human>();
            int[] marks;
            bool condition = false;
            int i = 0;

            foreach (Human human in _humans)
            {
                if (human is Student)
                {
                    marks = (human as Student).Marks;
                    condition = false;

                    for (i = 0; i < marks.Length && !condition; i++)
                    {
                        if (marks[i] >= 1 && marks[i] <= 3)
                        {
                            humans.Add(human);
                            condition = true;
                        }
                    }
                }
            }

            humans.Sort(new HumanAgeComparator());

            humans.Reverse();

            ShowAllHumans(humans);
        }
    }
}
