﻿namespace Lab_8
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.HumanListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lessonComboBox = new System.Windows.Forms.ComboBox();
            this.ShowLoadByLession = new System.Windows.Forms.Button();
            this.ShowSurnamesByAlphabetBtn = new System.Windows.Forms.Button();
            this.ShowWorstStudentsBtn = new System.Windows.Forms.Button();
            this.ShowAllHumansBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // HumanListBox
            // 
            this.HumanListBox.FormattingEnabled = true;
            this.HumanListBox.Location = new System.Drawing.Point(12, 12);
            this.HumanListBox.Name = "HumanListBox";
            this.HumanListBox.Size = new System.Drawing.Size(364, 316);
            this.HumanListBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(382, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Предмет:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lessonComboBox
            // 
            this.lessonComboBox.FormattingEnabled = true;
            this.lessonComboBox.Items.AddRange(new object[] {
            "ОАИП",
            "СЕТИ",
            "ООП"});
            this.lessonComboBox.Location = new System.Drawing.Point(443, 17);
            this.lessonComboBox.Name = "lessonComboBox";
            this.lessonComboBox.Size = new System.Drawing.Size(121, 21);
            this.lessonComboBox.TabIndex = 2;
            // 
            // ShowLoadByLession
            // 
            this.ShowLoadByLession.Location = new System.Drawing.Point(385, 44);
            this.ShowLoadByLession.Name = "ShowLoadByLession";
            this.ShowLoadByLession.Size = new System.Drawing.Size(179, 23);
            this.ShowLoadByLession.TabIndex = 3;
            this.ShowLoadByLession.Text = "Средняя нагрузка";
            this.ShowLoadByLession.UseVisualStyleBackColor = true;
            this.ShowLoadByLession.Click += new System.EventHandler(this.ShowLoadByLession_Click);
            // 
            // ShowSurnamesByAlphabetBtn
            // 
            this.ShowSurnamesByAlphabetBtn.Location = new System.Drawing.Point(385, 73);
            this.ShowSurnamesByAlphabetBtn.Name = "ShowSurnamesByAlphabetBtn";
            this.ShowSurnamesByAlphabetBtn.Size = new System.Drawing.Size(179, 23);
            this.ShowSurnamesByAlphabetBtn.TabIndex = 4;
            this.ShowSurnamesByAlphabetBtn.Text = "Показать по алфавиту";
            this.ShowSurnamesByAlphabetBtn.UseVisualStyleBackColor = true;
            // 
            // ShowWorstStudentsBtn
            // 
            this.ShowWorstStudentsBtn.Location = new System.Drawing.Point(385, 102);
            this.ShowWorstStudentsBtn.Name = "ShowWorstStudentsBtn";
            this.ShowWorstStudentsBtn.Size = new System.Drawing.Size(179, 23);
            this.ShowWorstStudentsBtn.TabIndex = 5;
            this.ShowWorstStudentsBtn.Text = "Студенты с плохой оценкой";
            this.ShowWorstStudentsBtn.UseVisualStyleBackColor = true;
            // 
            // ShowAllHumansBtn
            // 
            this.ShowAllHumansBtn.Location = new System.Drawing.Point(385, 131);
            this.ShowAllHumansBtn.Name = "ShowAllHumansBtn";
            this.ShowAllHumansBtn.Size = new System.Drawing.Size(179, 23);
            this.ShowAllHumansBtn.TabIndex = 6;
            this.ShowAllHumansBtn.Text = "Все записи";
            this.ShowAllHumansBtn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ShowAllHumansBtn);
            this.Controls.Add(this.ShowWorstStudentsBtn);
            this.Controls.Add(this.ShowSurnamesByAlphabetBtn);
            this.Controls.Add(this.ShowLoadByLession);
            this.Controls.Add(this.lessonComboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HumanListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox HumanListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox lessonComboBox;
        private System.Windows.Forms.Button ShowLoadByLession;
        private System.Windows.Forms.Button ShowSurnamesByAlphabetBtn;
        private System.Windows.Forms.Button ShowWorstStudentsBtn;
        private System.Windows.Forms.Button ShowAllHumansBtn;
    }
}

