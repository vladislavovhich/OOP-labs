﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using lab8;

namespace Lab_8
{
    public partial class Form1 : Form
    {
        public static List<Human> _humans = lab8.Program.ReadHumanFromFile();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        
        private void ShowLoadByLession_Click(object sender, EventArgs e)
        {
            string lesson = lessonComboBox.Text;
            double averageLoad = 0;
            int amount = 0;

            foreach (Human human in _humans)
            {
                if (human is Teacher)
                {
                    averageLoad += (human as Teacher)[lesson];
                    amount++;
                }
            }

            averageLoad /= amount;

            MessageBox.Show("Средняя нагрузка по предмету "+lesson+" равна "+averageLoad.ToString()+" часов!");
        }
    }
}
