﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class Human
    {
        protected string _surname;
        protected DateTime _birthDate;
        protected string _status;
       
        public Human(string surname, string status, int year)
        {
            _surname = surname;
            _birthDate = new DateTime(year, 1, 1);
            _status = status;
        }

        public string Surname
        {
            get => _surname;
        }
        public int BirthDate
        {
            get => _birthDate.Year;
        }
     
        public int Age
        {
            get => new DateTime(2022, 1, 1).Year - _birthDate.Year;
        }

        public virtual string Information()
        {
          
            return _surname + " " + _status + " " + _birthDate.Year;
        }
    }
}
