﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class Teacher : Human
    {
        protected Dictionary<string, int> _load = new Dictionary<string, int>();

        public int this[string index]
        {
            get => _load[index];
            set => _load[index] = value;
        }

        public Teacher(string surname, string status, int year, int[] load) : base(surname, status, year)
        {
            
            _load["ОАИП"] = load[0];
            _load["СЕТИ"] = load[1];
            _load["ООП"] = load[2];
        }

        protected double CalcAverageLoad()
        {
            double averageLoad = 0;

            foreach (int load in _load.Values)
            {
                averageLoad += load;
            }

            return Math.Floor(averageLoad / _load.Count);
        }

        
        public override string Information()
        {
            string load = "";

            foreach (int loadVal in _load.Values)
            {
                load += loadVal.ToString() + " ";
            }
            return base.Information() + " " + load;
        }
    }
}
