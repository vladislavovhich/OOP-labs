﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class HumanSurnameComparator : IComparer<Human>
    {
        public int Compare(Human human1, Human human2)
        {
            return human1.Surname.CompareTo(human2.Surname);
        }
    }
}
