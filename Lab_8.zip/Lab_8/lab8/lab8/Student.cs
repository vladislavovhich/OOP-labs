﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class Student : Human
    {
        protected int[] _sessionResults;
        public Student(string surname, string status, int year, int[] sessionResults) : base(surname, status, year)
        {
            _sessionResults = sessionResults;
        }

        public int[] Marks
        {
            get => _sessionResults;
        }
        protected double CalcAverageGrade()
        {
            double averageGrade = 0;

            foreach (int grade in _sessionResults)
            {
                averageGrade += grade;
            }

            return Math.Floor(averageGrade / _sessionResults.Length);
        }
        public override string Information()
        {
            string marks = "";

            for (int i = 0; i < _sessionResults.Length; i++)
            {
                marks += _sessionResults[i].ToString() + " ";
            }
            return base.Information() + " " + marks;
        }
    }
}
