﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ReadHumanFromFile();
          
        }
        public static List<Human> ReadHumanFromFile()
        {
            List<Human> humans = new List<Human>();

            string line;

        
                StreamReader sr = new StreamReader("E:/ООП/Lab_8/lab8/humans.txt");
            
                line = sr.ReadLine();

                string[] paramz;
  
                string surname, status;
                int year, i, j;
                int[] gradesOrLoad = new int[1];
               
                    
                while (line != null)
                {
                    paramz = line.Split(' ');

                    if (paramz.Length == 1)
                    {
                    line = sr.ReadLine();
                    continue;
                   
                }
                    surname = paramz[0];
                    year = int.Parse(paramz[1]);
                    status = paramz[2];

                    if (status == "teacher" || status == "student")
                    {
                        gradesOrLoad = new int[paramz.Length - 3];
                    
                        for (i = 3, j = 0; j < gradesOrLoad.Length; i++, j++)
                        {
                            gradesOrLoad[j] = int.Parse(paramz[i]);
                        }
                    }

             
                    switch (status)
                    {
                        case "student":
                            humans.Add(new Student(surname, status, year, gradesOrLoad));
                            break;
                        case "teacher":
                            humans.Add(new Teacher(surname, status, year, gradesOrLoad));
                            break;
                        default:
                            humans.Add(new Human(surname, status, year));
                            break;
                    }
                    
                    line = sr.ReadLine();
                }
             
                sr.Close();
           
            return humans;
        }
    }
}
