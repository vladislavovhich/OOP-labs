﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_2;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            Matrix m1 = new Matrix(3, 3);
            Matrix m2 = new Matrix(3, 3);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[3, 3] { { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 } };
            m2.Elements = new double[3, 3] { { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 } };
            m3.Elements = new double[3, 3] { { 6, 12, 18 }, { 6, 12, 18 }, { 6, 12, 18 } };

            m4 = m1 * m2;

            int i1 = 1;

            for (int i = 0; i < m4.Rows; i++)
            {
                for (int j = 0; j < m4.Columns; j++)
                {
                    if (m4.Elements[i, j] != m3.Elements[i, j])
                    {
                        i1 = -1;
                    }
                }
            }

            Assert.AreEqual(1, i1);
        }

        [TestMethod]
        public void TestMethod2()
        {
            Matrix m1 = new Matrix(3, 4);
            Matrix m2 = new Matrix(4, 3);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[3, 4] { { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 } };
            m2.Elements = new double[4, 3] { { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 } };
            m3.Elements = new double[3, 3] { { 10, 20, 30 }, { 10, 20, 30 }, { 10, 20, 30 } };

            m4 = m1 * m2;

            int i1 = 1;

            for (int i = 0; i < m4.Rows; i++)
            {
                for (int j = 0; j < m4.Columns; j++)
                {
                    if (m4.Elements[i, j] != m3.Elements[i, j])
                    {
                        i1 = -1;
                    }
                }
            }

            Assert.AreEqual(1, i1);
        }

        [TestMethod]
        public void TestMethod3()
        {
            Matrix m1 = new Matrix(3, 4);
            Matrix m2 = new Matrix(1, 3);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[3, 4] { { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 } };
            m2.Elements = new double[4, 3] { { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 } };

            m4 = m1 * m2;



            Assert.AreEqual(m4.Rows + m4.Columns, 0);
        }

        [TestMethod]
        public void TestMethod4()
        {
            Matrix m1 = new Matrix(2, 4);
            Matrix m2 = new Matrix(1, 3);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[3, 4] { { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 } };
            m2.Elements = new double[4, 3] { { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 } };

            m4 = m1 * m2;



            Assert.AreEqual(m4.Rows + m4.Columns, 0);
        }

        [TestMethod]
        public void TestMethod5()
        {
            Matrix m1 = new Matrix(2, 4);
            Matrix m2 = new Matrix(2, 3);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[3, 4] { { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 } };
            m2.Elements = new double[4, 3] { { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 }, { 1, 2, 3 } };

            m4 = m1 * m2;



            Assert.AreEqual(m4.Rows + m4.Columns, 0);
        }

        [TestMethod]
        public void TestMethod6()
        {

            Matrix m1 = new Matrix(1, 3);
            Matrix m2 = new Matrix(3, 1);

            ;
            Matrix m3 = new Matrix(1, 1);
            Matrix m4;

            m1.Elements = new double[1, 3] { { 1, 20, -3 } };
            m2.Elements = new double[3, 1] { { 15 }, { 88 }, { 22 } };
            m3.Elements = new double[1, 1] { { 1709 } };

            m4 = m1 * m2;

            int i1 = 1;

            for (int i = 0; i < m4.Rows; i++)
            {
                for (int j = 0; j < m4.Columns; j++)
                {
                    if (m4.Elements[i, j] != m3.Elements[i, j])
                    {
                        i1 = -1;
                    }
                }
            }

            Assert.AreEqual(1, i1);
        }

        [TestMethod]
        public void TestMethod7()
        {

            Matrix m1 = new Matrix(1, 3);
            Matrix m2 = new Matrix(4, 1);

            ;
            Matrix m3 = new Matrix(1, 1);
            Matrix m4;

            m1.Elements = new double[1, 3] { { 1, 20, -3 } };
            m2.Elements = new double[4, 1] { { 15 }, { 88 }, { 22 }, { 3 } };

            m4 = m1 * m2;

            Assert.AreEqual(m4.Rows + m4.Columns, 0);
        }

        [TestMethod]
        public void TestMethod8()
        {

            Matrix m1 = new Matrix(2, 3);
            Matrix m2 = new Matrix(4, 1);

            ;
            Matrix m3 = new Matrix(1, 1);
            Matrix m4;

            m1.Elements = new double[2, 3] { { 1, 20, -3 }, { 1, 20, -3 } };
            m2.Elements = new double[4, 1] { { 15 }, { 88 }, { 22 }, { 3 } };

            m4 = m1 * m2;

            Assert.AreEqual(m4.Rows + m4.Columns, 0);
        }

        [TestMethod]
        public void TestMethod9()
        {

            Matrix m1 = new Matrix(1, 3);
            Matrix m2 = new Matrix(3, 1);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[1, 3] { { 1, 20, -3 } };
            m2.Elements = new double[3, 1] { { 15 }, { 88 }, { 22 } };
            m3.Elements = new double[3, 3] { { 15, 300, -45 }, { 88, 1760, -264 }, { 22, 440, -66 } };

            m4 = m2 * m1;

            int i1 = 1;

            for (int i = 0; i < m4.Rows; i++)
            {
                for (int j = 0; j < m4.Columns; j++)
                {
                    if (m4.Elements[i, j] != m3.Elements[i, j])
                    {
                        i1 = -1;
                    }
                }
            }

            Assert.AreEqual(1, i1);
        }

        [TestMethod]
        public void TestMethod10()
        {

            Matrix m1 = new Matrix(1, 4);
            Matrix m2 = new Matrix(4, 1);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[1, 4] { { 1, 20, -3, 4 } };
            m2.Elements = new double[4, 1] { { 15 }, { 88 }, { 22 }, { 30 } };
            m3.Elements = new double[3, 3] { { 15, 300, -45 }, { 88, 1760, -264 }, { 22, 440, -66 } };

            m4 = m1 * m2;

            int i1 = 1;

            Assert.AreEqual(m4.Rows, 1);
        }

        [TestMethod]
        public void TestMethod11()
        {

            Matrix m1 = new Matrix(1, 4);
            Matrix m2 = new Matrix(4, 1);
            Matrix m3 = new Matrix(3, 3);
            Matrix m4;

            m1.Elements = new double[1, 4] { { 1, 20, -3, 4 } };
            m2.Elements = new double[4, 1] { { 15 }, { 88 }, { 22 }, { 30 } };
            m3.Elements = new double[3, 3] { { 15, 300, -45 }, { 88, 1760, -264 }, { 22, 440, -66 } };

            m4 = m2 * m1;

            Assert.AreEqual(m4.Rows, 4);
        }

        [TestMethod]
        public void TestMethod12()
        {

            Matrix m1 = new Matrix(2, 4);
            Matrix m2 = new Matrix(4, 2);

            Matrix m4;

            m1.Elements = new double[2, 4] { { 1, 20, -3, 4 }, { 1, 20, -3, 4 } };
            m2.Elements = new double[4, 2] { { 15, 2 }, { 88, 3 }, { 22, 3 }, { 30, 3 } };

            m4 = m1 * m2;

            Assert.AreEqual(m4.Columns, 2);

        }

        [TestMethod]
        public void TestMethod13()
        {

            Matrix m1 = new Matrix(1, 4);
            Matrix m2 = new Matrix(5, 2);

            Matrix m4;

            m1.Elements = new double[1, 4] { { 1, 20, -3, 4 } };
            m2.Elements = new double[5, 2] { { 15, 2 }, { 88, 3 }, { 22, 3 }, { 30, 3 }, { 30, 3 } };

            m4 = m1 * m2;

            Assert.IsTrue(m4.Columns == 0 && m4.Rows == 0);

        }

        [TestMethod]
        public void TestMethod14()
        {

            Matrix m1 = new Matrix(7, 1);
            Matrix m2 = new Matrix(1, 7);
            Matrix m3 = new Matrix(7, 7);
            Matrix m4;

            m1.Elements = new double[7, 1] { { 1 }, { 2 }, { 3 }, { 4 }, { 5 }, { 6 }, { 7 } };
            m2.Elements = new double[1, 7] { { 1, 2, 3, 4, 5, 6, 7 } };
            m3.Elements = new double[7, 7] { { 1, 2, 3, 4, 5, 6, 7 }, { 2, 4, 6, 8, 10, 12, 14 }, { 3, 6, 9, 12, 15, 18, 21 }, { 4, 8, 12, 16, 20, 24, 28 }, { 5, 10, 15, 20, 25, 30, 35 }, { 6, 12, 18, 24, 30, 36, 42 }, { 7, 14, 21, 28, 35, 42, 49 } };

            m4 = m1 * m2;

            int i1 = 1;

            for (int i = 0; i < m4.Rows; i++)
            {
                for (int j = 0; j < m4.Columns; j++)
                {
                    if (m4.Elements[i, j] != m3.Elements[i, j])
                    {
                        i1 = -1;
                    }
                }
            }

            Assert.AreEqual(m4.Rows == 4, m4.Columns == 4);
        }

        [TestMethod]
        public void TestMethod15()
        {

            Matrix m1 = new Matrix(7, 1);
            Matrix m2 = new Matrix(1, 7);
            Matrix m3 = new Matrix(1, 1);
            Matrix m4;

            m1.Elements = new double[7, 1] { { 1 }, { 2 }, { 3 }, { 4 }, { 5 }, { 6 }, { 7 } };
            m2.Elements = new double[1, 7] { { 1, 2, 3, 4, 5, 6, 7 } };
            m3.Elements = new double[1, 1] { { 140 } };

            m4 = m2 * m1;

            int i1 = 1;

            for (int i = 0; i < m4.Rows; i++)
            {
                for (int j = 0; j < m4.Columns; j++)
                {
                    if (m4.Elements[i, j] != m3.Elements[i, j])
                    {
                        i1 = -1;
                    }
                }
            }

            Assert.IsTrue(i1 == 1 && m4.Rows == 1 && m4.Columns == 1);
        }
    }
}
