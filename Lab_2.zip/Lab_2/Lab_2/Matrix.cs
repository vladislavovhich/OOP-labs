﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    public struct Matrix
    {
        public int Columns, Rows;
        public double[,] Elements;

        public Matrix(int rows, int columns)
        {
            Columns = columns;
            Rows = rows;

            Elements = new double[Columns, Rows];
        }

        public void Fill()
        {
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    Console.Write("A[{0}][{1}] = ", i, j);

                    Elements[i, j] = Convert.ToDouble(Console.ReadLine());
                }

                Console.WriteLine();
            }
        }
        public void Print()
        {
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    Console.Write("{0,8:F2}", Elements[i, j]);
                }

                Console.WriteLine();
            }

            Console.WriteLine();
        }

        public static Matrix operator *(Matrix m1, Matrix m2)
        {
            if (m1.Columns != m2.Rows)
            {
                Console.WriteLine("It's impossible to multiple two matrices!");

                return new Matrix();
            }

            Matrix matrix = new Matrix(m2.Columns, m1.Rows);
            double sum = 0;

            for (int i = 0; i < matrix.Rows; i++)
            {
                for (int j = 0; j < matrix.Columns; j++)
                {
                    sum = 0;

                    for (int j1 = 0; j1 < m1.Columns; j1++)
                    {
                        sum += m2.Elements[j1, j] * m1.Elements[i, j1];
                    }

                    matrix.Elements[i, j] = sum;
                }
            }

            return matrix;
        }
    }
}
