﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix m = new Matrix(2, 3);
            Matrix m1 = new Matrix(4, 1);

            m.Elements = new double[2, 3] { { 1, 20, -3 }, { 23, 3, 4 } };
            m1.Elements = new double[4, 1] { { 15 }, { 88 }, { 22 }, { 2 } };

            m.Print();
            m1.Print();

            Matrix result = m1 * m;

            result.Print();

            Console.Read();
        }
    }
}
