﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    public class Bus
    {
        public double Price;
        public int WeekDay;

        public Bus(double price, int weekDay)
        {
            Price = price;
            WeekDay = weekDay;
        }

    }
}
