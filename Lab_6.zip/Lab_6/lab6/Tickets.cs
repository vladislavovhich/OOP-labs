﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    public class Tickets
    {
        private List<Bus> _tickets;
        private int _ticketsTypeAmount;
        private string[] _ticketsNames;
        private string[] _weekDays = new string[]
        {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье",
        };
        private enum _ticketsTypes
        {
            Bus, Trolleybus, Tram
        }

        public Tickets()
        {
            _tickets = new List<Bus>();
            _ticketsTypeAmount = Enum.GetValues(typeof(_ticketsTypes)).Length;
            _ticketsNames = Enum.GetNames(typeof(_ticketsTypes));
        }

        public string[] GetWeekDays()
        {
            return _weekDays;
        }

        public string[] GetTicketsTypes()
        {
            return _ticketsNames;
        }
        public void Add(Bus bus)
        {
            _tickets.Add(bus);
        }

        public List<Bus> Get()
        {
            return _tickets;
        }

        public Bus Get(int index)
        {
            return _tickets[index];
        }

        public List<Bus> Get(int from, int to)
        {
            List<Bus> tickets = new List<Bus>();

            foreach (Bus bus in _tickets)
            {
                if (bus.WeekDay >= from && bus.WeekDay <= to)
                {
                    tickets.Add(bus);
                }
            }

            return tickets;
        }

        public double[] GetSoldByWeek()
        {
            double[] weekDay = new double[7];
          
            foreach (Bus bus in _tickets)
            {
                weekDay[bus.WeekDay] += bus.Price;
              
            }

            return weekDay;
        }
        public int GetWeekDayNumber(string str)
        {
            switch (str)
            {
                case "Понедельник":
                    return 0;
                case "Вторник":
                    return 1;
                case "Среда":
                    return 2;
                case "Четверг":
                    return 3;
                case "Пятница":
                    return 4;
                case "Суббота":
                    return 5;
                case "Воскресенье":
                    return 6;
                default:

                    return -1;
            }

        }
        public double[] GetAverageByType()
        {
            double[] ticketsAmount = new double[_ticketsTypeAmount];
            int i;

            foreach (Bus bus in _tickets)
            {
                for (i = 0; i < _ticketsTypeAmount; i++)
                {
                    if (bus.GetType().Name.ToString() == _ticketsNames[i])
                    {
                        ticketsAmount[i] += bus.Price;
                    }
                }
            }

            for (i = 0; i < _ticketsTypeAmount; i++)
            {
                ticketsAmount[i] /= _tickets.Count;
            }

            return ticketsAmount;
        }
    }
}
