﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    
        private void button1_Click(object sender, EventArgs e)
        {
            string ticketType = (string)TicketTypeBox.SelectedItem;
            string priceStr = PriceBox.Text;
            int weekDay = Program.tickets.GetWeekDayNumber((string)EnterDayBox.SelectedItem);
           
            double price = 0;

           
            if (Double.TryParse(priceStr, out price))
            {
                switch (ticketType)
                {
                    case "Автобус":
                        Program.tickets.Add(new lab6.Bus(price, weekDay));
                      
                        break;
                    case "Троллейбус":
                        Program.tickets.Add(new lab6.Trolleybus(price, weekDay));
                       
                        break;
                    case "Трамвай":
                        Program.tickets.Add(new lab6.Tram(price, weekDay));
                       
                        break;
                    default:
                        MessageBox.Show(":(");
                        break;
                }

                PriceBox.Text = "";

                ShowTickets(Program.tickets.Get());

                MessageBox.Show("Билет успешно добавлен!");
            }
            else
            {
                MessageBox.Show("Цена должна быть записана цифрами!");
            }
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void PeriodFromBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void ShowTickets(List<lab6.Bus> tickets)
        {
            TicketsList.Items.Clear();
            string[] weekDays = Program.tickets.GetWeekDays();

            foreach (lab6.Bus ticket in tickets)
            {
                TicketsList.Items.Add("Тип: " + ticket.GetType().Name.ToString() + ", Цена: " + ticket.Price.ToString() + ", День: " + weekDays[ticket.WeekDay]);
            }
        }

        private void ShowSoldByDays()
        {
            double[] soldByDay = Program.tickets.GetSoldByWeek();
            string[] weekDays = Program.tickets.GetWeekDays();
            int i;

            TicketsList.Items.Clear();

            for (i = 0; i < soldByDay.Length; i++)
            {

                TicketsList.Items.Add("День: " + weekDays[i] + ", Продано: " + soldByDay[i].ToString() + " р.");
            }
        }

        private void ShowSoldByTypes()
        {
            double[] soldByType = Program.tickets.GetAverageByType();
            string[] types = Program.tickets.GetTicketsTypes();
            int i;

            TicketsList.Items.Clear();

            for (i = 0; i < soldByType.Length; i++)
            {
                TicketsList.Items.Add("Тип: " + types[i] + ", Продано: " + soldByType[i].ToString() + " р.");
            }
        }

        private void ShowTicketsByTime_Click(object sender, EventArgs e)
        {
            string fromStr = PeriodFromBox.Text;
            string toStr = PeriodToBox.Text;

            int from, to;

            if (int.TryParse(fromStr, out from) && int.TryParse(toStr, out to))
            {
                if (from >= 1 && from <= 7 && to >= 1 && to <= 7 && from < to)
                {
                    List<lab6.Bus> tickets = new List<lab6.Bus>();

                    PeriodFromBox.Text = "";
                    PeriodToBox.Text = "";

                    tickets = Program.tickets.Get(from - 1, to - 1);

                    ShowTickets(tickets);
                }
                else
                {
                    MessageBox.Show("Значение должно быть от 1 до 7!");
                }
            }
        }

        private void ShowAllTicketsBtn_Click(object sender, EventArgs e)
        {
            ShowTickets(Program.tickets.Get());
        }

        private void ShowAveragePerWeek_Click(object sender, EventArgs e)
        {
            ShowSoldByDays();
        }

        private void ShowTicketsSellsPerWeekBtn_Click(object sender, EventArgs e)
        {
            ShowSoldByTypes();
        }
    }
}
