﻿namespace lab6_interface
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.TicketTypeLabel = new System.Windows.Forms.Label();
            this.PriceBox = new System.Windows.Forms.TextBox();
            this.DateLabel = new System.Windows.Forms.Label();
            this.PriceLabel = new System.Windows.Forms.Label();
            this.AddTicketBtn = new System.Windows.Forms.Button();
            this.TicketsLabel = new System.Windows.Forms.Label();
            this.ShowAveragePerWeek = new System.Windows.Forms.Button();
            this.ShowTicketsSellsPerWeekBtn = new System.Windows.Forms.Button();
            this.ShowTicketsByTime = new System.Windows.Forms.Button();
            this.TicketsList = new System.Windows.Forms.ListBox();
            this.EnterDayBox = new System.Windows.Forms.ComboBox();
            this.TicketTypeBox = new System.Windows.Forms.ComboBox();
            this.PeriodToBox = new System.Windows.Forms.TextBox();
            this.PeriodFromBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ShowAllTicketsBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TicketTypeLabel
            // 
            this.TicketTypeLabel.AutoSize = true;
            this.TicketTypeLabel.Location = new System.Drawing.Point(30, 9);
            this.TicketTypeLabel.Name = "TicketTypeLabel";
            this.TicketTypeLabel.Size = new System.Drawing.Size(29, 13);
            this.TicketTypeLabel.TabIndex = 1;
            this.TicketTypeLabel.Text = "Тип:";
            this.TicketTypeLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // PriceBox
            // 
            this.PriceBox.Location = new System.Drawing.Point(68, 40);
            this.PriceBox.Name = "PriceBox";
            this.PriceBox.Size = new System.Drawing.Size(186, 20);
            this.PriceBox.TabIndex = 2;
            this.PriceBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // DateLabel
            // 
            this.DateLabel.AutoSize = true;
            this.DateLabel.Location = new System.Drawing.Point(23, 81);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(36, 13);
            this.DateLabel.TabIndex = 3;
            this.DateLabel.Text = "Дата:";
            this.DateLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // PriceLabel
            // 
            this.PriceLabel.AutoSize = true;
            this.PriceLabel.Location = new System.Drawing.Point(23, 40);
            this.PriceLabel.Name = "PriceLabel";
            this.PriceLabel.Size = new System.Drawing.Size(36, 13);
            this.PriceLabel.TabIndex = 4;
            this.PriceLabel.Text = "Цена:";
            this.PriceLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // AddTicketBtn
            // 
            this.AddTicketBtn.Location = new System.Drawing.Point(12, 118);
            this.AddTicketBtn.Name = "AddTicketBtn";
            this.AddTicketBtn.Size = new System.Drawing.Size(242, 23);
            this.AddTicketBtn.TabIndex = 8;
            this.AddTicketBtn.Text = "Добавить";
            this.AddTicketBtn.UseVisualStyleBackColor = true;
            this.AddTicketBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // TicketsLabel
            // 
            this.TicketsLabel.AutoSize = true;
            this.TicketsLabel.Location = new System.Drawing.Point(111, 158);
            this.TicketsLabel.Name = "TicketsLabel";
            this.TicketsLabel.Size = new System.Drawing.Size(48, 13);
            this.TicketsLabel.TabIndex = 9;
            this.TicketsLabel.Text = "Билеты:";
            this.TicketsLabel.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // ShowAveragePerWeek
            // 
            this.ShowAveragePerWeek.Location = new System.Drawing.Point(12, 263);
            this.ShowAveragePerWeek.Name = "ShowAveragePerWeek";
            this.ShowAveragePerWeek.Size = new System.Drawing.Size(242, 23);
            this.ShowAveragePerWeek.TabIndex = 10;
            this.ShowAveragePerWeek.Text = "Продано по дням";
            this.ShowAveragePerWeek.UseVisualStyleBackColor = true;
            this.ShowAveragePerWeek.Click += new System.EventHandler(this.ShowAveragePerWeek_Click);
            // 
            // ShowTicketsSellsPerWeekBtn
            // 
            this.ShowTicketsSellsPerWeekBtn.Location = new System.Drawing.Point(12, 234);
            this.ShowTicketsSellsPerWeekBtn.Name = "ShowTicketsSellsPerWeekBtn";
            this.ShowTicketsSellsPerWeekBtn.Size = new System.Drawing.Size(242, 23);
            this.ShowTicketsSellsPerWeekBtn.TabIndex = 11;
            this.ShowTicketsSellsPerWeekBtn.Text = "Продано по типам";
            this.ShowTicketsSellsPerWeekBtn.UseVisualStyleBackColor = true;
            this.ShowTicketsSellsPerWeekBtn.Click += new System.EventHandler(this.ShowTicketsSellsPerWeekBtn_Click);
            // 
            // ShowTicketsByTime
            // 
            this.ShowTicketsByTime.Location = new System.Drawing.Point(12, 176);
            this.ShowTicketsByTime.Name = "ShowTicketsByTime";
            this.ShowTicketsByTime.Size = new System.Drawing.Size(75, 23);
            this.ShowTicketsByTime.TabIndex = 12;
            this.ShowTicketsByTime.Text = "За период";
            this.ShowTicketsByTime.UseVisualStyleBackColor = true;
            this.ShowTicketsByTime.Click += new System.EventHandler(this.ShowTicketsByTime_Click);
            // 
            // TicketsList
            // 
            this.TicketsList.FormattingEnabled = true;
            this.TicketsList.Location = new System.Drawing.Point(273, 5);
            this.TicketsList.Name = "TicketsList";
            this.TicketsList.Size = new System.Drawing.Size(343, 277);
            this.TicketsList.TabIndex = 14;
            // 
            // EnterDayBox
            // 
            this.EnterDayBox.FormattingEnabled = true;
            this.EnterDayBox.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.EnterDayBox.Location = new System.Drawing.Point(68, 78);
            this.EnterDayBox.Name = "EnterDayBox";
            this.EnterDayBox.Size = new System.Drawing.Size(186, 21);
            this.EnterDayBox.TabIndex = 6;
            this.EnterDayBox.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // TicketTypeBox
            // 
            this.TicketTypeBox.DisplayMember = "1";
            this.TicketTypeBox.FormattingEnabled = true;
            this.TicketTypeBox.Items.AddRange(new object[] {
            "Автобус",
            "Троллейбус",
            "Трамвай"});
            this.TicketTypeBox.Location = new System.Drawing.Point(68, 5);
            this.TicketTypeBox.Name = "TicketTypeBox";
            this.TicketTypeBox.Size = new System.Drawing.Size(186, 21);
            this.TicketTypeBox.TabIndex = 0;
            this.TicketTypeBox.ValueMember = "1";
            this.TicketTypeBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // PeriodToBox
            // 
            this.PeriodToBox.Location = new System.Drawing.Point(207, 178);
            this.PeriodToBox.Name = "PeriodToBox";
            this.PeriodToBox.Size = new System.Drawing.Size(47, 20);
            this.PeriodToBox.TabIndex = 15;
            // 
            // PeriodFromBox
            // 
            this.PeriodFromBox.Location = new System.Drawing.Point(124, 179);
            this.PeriodFromBox.Name = "PeriodFromBox";
            this.PeriodFromBox.Size = new System.Drawing.Size(52, 20);
            this.PeriodFromBox.TabIndex = 16;
            this.PeriodFromBox.TextChanged += new System.EventHandler(this.PeriodFromBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(182, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "До:";
            this.label1.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "От:";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // ShowAllTicketsBtn
            // 
            this.ShowAllTicketsBtn.Location = new System.Drawing.Point(12, 205);
            this.ShowAllTicketsBtn.Name = "ShowAllTicketsBtn";
            this.ShowAllTicketsBtn.Size = new System.Drawing.Size(242, 23);
            this.ShowAllTicketsBtn.TabIndex = 19;
            this.ShowAllTicketsBtn.Text = "Все билеты";
            this.ShowAllTicketsBtn.UseVisualStyleBackColor = true;
            this.ShowAllTicketsBtn.Click += new System.EventHandler(this.ShowAllTicketsBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ShowAllTicketsBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PeriodFromBox);
            this.Controls.Add(this.PeriodToBox);
            this.Controls.Add(this.TicketsList);
            this.Controls.Add(this.ShowTicketsByTime);
            this.Controls.Add(this.ShowTicketsSellsPerWeekBtn);
            this.Controls.Add(this.ShowAveragePerWeek);
            this.Controls.Add(this.TicketsLabel);
            this.Controls.Add(this.AddTicketBtn);
            this.Controls.Add(this.EnterDayBox);
            this.Controls.Add(this.PriceLabel);
            this.Controls.Add(this.DateLabel);
            this.Controls.Add(this.PriceBox);
            this.Controls.Add(this.TicketTypeLabel);
            this.Controls.Add(this.TicketTypeBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label TicketTypeLabel;
        private System.Windows.Forms.TextBox PriceBox;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label PriceLabel;
        private System.Windows.Forms.Button AddTicketBtn;
        private System.Windows.Forms.Label TicketsLabel;
        private System.Windows.Forms.Button ShowAveragePerWeek;
        private System.Windows.Forms.Button ShowTicketsSellsPerWeekBtn;
        private System.Windows.Forms.Button ShowTicketsByTime;
        private System.Windows.Forms.ListBox TicketsList;
        private System.Windows.Forms.ComboBox EnterDayBox;
        private System.Windows.Forms.ComboBox TicketTypeBox;
        private System.Windows.Forms.TextBox PeriodToBox;
        private System.Windows.Forms.TextBox PeriodFromBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ShowAllTicketsBtn;
    }
}

