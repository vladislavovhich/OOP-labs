﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lab_7;

namespace Lab7_Interface
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AnimalsList _animalList = new AnimalsList();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ShowAnimals(List<Animal> animals)
        {
            AnimalsListBox.Items.Clear();

            foreach (Animal animal in animals)
            {
                AnimalsListBox.Items.Add("Животное: " + animal.GetAnimalType() + ", Имя: " + animal.GetName() + ", Возраст: " + animal.GetAge().ToString() + ", Цвет: " + animal.GetColor() + ", Порода(Тип): " + animal.GetEspecialProps());
            }
        }

        private void AddAnimalBtn_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text;
            string color = ColorTextBox.Text;
            string breed = BreedTextBox.Text;
            string ageStr = AgeTextBox.Text;
            string animalType = AnimalTypeBox.Text;

            int age;

            Animal animal;

            if (name.Trim() == "" || ((animalType == "Кот" || animalType == "Собака") && breed.Trim() == "") || color.Trim() == "" || ageStr.Trim() == "")
            {
                MessageBox.Show("Вы не ввели некоторые значения!");
            }
            else if (int.TryParse(ageStr, out age))
            {
                switch (animalType)
                {
                    case "Кот":
                        animal = new Cat(name, age, breed, color);
                        break;
                    case "Собака":
                        animal = new Dog(name, age, breed, color);
                        break;
                    case "Попугай":
                        animal = new Perrot(name, age, breed, color);
                        break;
                    default:
                        animal = new Animal("", 0, "");
                        break;
                }

                _animalList.Add(animal);

                ShowAnimals(_animalList.Get());

                MessageBox.Show("Животное успешно добавлено!");
            }
            else
            {
                MessageBox.Show("Возраст должен быть цифрой!");
            }

        }

        private void ShowAllBtn_Click(object sender, RoutedEventArgs e)
        {
            ShowAnimals(_animalList.Get());
        }

        private void AverageAgeBtn_Click(object sender, RoutedEventArgs e)
        {
            double[] averageAges = _animalList.CalcAverageAgeByType();
            string[] animalsTypes = _animalList.GetAnimalsTypes();

            AnimalsListBox.Items.Clear();

            int i;

            for (i = 0; i < animalsTypes.Length; i++)
            {
                AnimalsListBox.Items.Add("Тип: " + animalsTypes[i] + ", Средний возраст: " + averageAges[i]);
            }
        }

        private void CatsDogsBreeds_Click(object sender, RoutedEventArgs e)
        {
            List<string>[] breeds = _animalList.GetAllBreedsCatsAndDogs();

            AnimalsListBox.Items.Clear();

            foreach (string catBreed in breeds[0])
            {
                AnimalsListBox.Items.Add("Тип: " + "Сat, Порода: " + catBreed);
            }

            foreach (string dogBreed in breeds[1])
            {
                AnimalsListBox.Items.Add("Тип: " + "Dog, Порода: " + dogBreed);
            }
        }

        private void ShowSameNameBtn_Click(object sender, RoutedEventArgs e)
        {
            ShowAnimals(_animalList.GetSameNameAnimals());
        }
    }
}
