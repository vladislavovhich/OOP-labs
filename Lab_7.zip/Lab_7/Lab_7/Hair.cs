﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public class Hair
    {
        protected string _name;

        public Hair(string name)
        {
            _name = name;
        }

        public string GetName()
        {
            return _name;
        }
    }
}
