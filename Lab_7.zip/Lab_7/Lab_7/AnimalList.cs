﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public class AnimalsList
    {
        private List<Animal> _animals = new List<Animal>();

        private enum _animalsTypes
        {
            Dog, Cat, Perrot
        }
        private enum _hairTypes
        {
            Fur, Feather, Scale
        }

        private string[] _animalsTypesNames = Enum.GetNames(typeof(_animalsTypes));
        private string[] _hairTypesNames = Enum.GetNames(typeof(_hairTypes));

        public string[] GetAnimalsTypes()
        {
            return _animalsTypesNames;
        }
        public void Add(Animal animal)
        {
            _animals.Add(animal);
        }

        public List<Animal> Get()
        {
            return _animals;
        }

        public double[] CalcAverageAgeByType()
        {
            double[] averageAges = new double[_animalsTypesNames.Length];
            double[] entriesAmount = new double[_animalsTypesNames.Length];

            int index, i;

            foreach (Animal animal in _animals)
            {
                index = Array.IndexOf(_animalsTypesNames, animal.GetType().Name.ToString());

                averageAges[index] += animal.GetAge();
                entriesAmount[index] += 1;
            }

            for (i = 0; i < averageAges.Length; i++)
            {
                if (entriesAmount[i] != 0)
                {
                    averageAges[i] /= entriesAmount[i];
                }
            }


            return averageAges;
        }

        public List<Animal> GetSameNameAnimals()
        {
            List<Animal> sameNameAnimals = new List<Animal>();

            int i, j;

            for (i = 0; i < _animals.Count; i++)
            {
                for (j = i + 1; j < _animals.Count; j++)
                {
                    if (_animals[i].GetName() == _animals[j].GetName())
                    {
                        sameNameAnimals.Add(_animals[i]);
                        sameNameAnimals.Add(_animals[j]);
                    }
                }
            }

            return sameNameAnimals;
        }

        public List<string>[] GetAllBreedsCatsAndDogs()
        {
            List<string> catBreeds = new List<string>();
            List<string> dogBreeds = new List<string>();
            List<string>[] breeds = new List<string>[2];

            string breed;

            foreach (Animal animal in _animals)
            {
                breed = animal.GetEspecialProps();

                if (animal.GetAnimalType() == "Cat" && !catBreeds.Contains(breed))
                {
                    catBreeds.Add(breed);
                }
                else if (animal.GetAnimalType() == "Dog" && !dogBreeds.Contains(breed))
                {
                    dogBreeds.Add(breed);
                }
            }

            breeds[0] = catBreeds;
            breeds[1] = dogBreeds;

            return breeds;
        }
    }
}
