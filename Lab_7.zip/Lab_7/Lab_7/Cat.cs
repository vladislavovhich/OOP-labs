﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public class Cat : Animal
    {
        protected string _breed;

        public Cat(string name, int age, string breed, string color) : base(name, age, color)
        {
            _breed = breed;
            _hair = new Fur();
        }

        public string GetBreed()
        {
            return _breed;
        }

        public override string GetEspecialProps()
        {
            return _breed;
        }
    }
}
