﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public class Dog : Animal
    {
        protected string _breed;

        public string Breed => _breed;

        public Dog(string name, int age, string breed, string color) : base(name, age, color)
        {
            _hair = new Fur();
            _breed = breed;
        }

        public string GetBreed()
        {
            return _breed;
        }

        public override string GetEspecialProps()
        {
            return _breed;
        }
    }
}
