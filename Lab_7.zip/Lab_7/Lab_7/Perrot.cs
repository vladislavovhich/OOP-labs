﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public class Perrot : Animal
    {
        protected string _type;

        public Perrot(string name, int age, string type, string color) : base(name, age, color)
        {
            _type = type;
            _hair = new Feather();
        }

        public string GetBirdType()
        {
            return _type;
        }

        public override string GetEspecialProps()
        {
            return _type;
        }
    }
}
