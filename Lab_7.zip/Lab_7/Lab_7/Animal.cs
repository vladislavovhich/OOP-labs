﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public class Animal
    {
        protected string _name;
        protected int _age;
        protected string _color;
        protected Hair _hair;

        public Animal(string name, int age, string color)
        {
            _name = name;
            _age = age;
            _color = color;
            _hair = new Hair("Шерсть");
        }

        public string GetName()
        {
            return _name;
        }

        public int GetAge()
        {
            return _age;
        }

        public string GetColor()
        {
            return _color;
        }

        public string GetAnimalType()
        {
            return this.GetType().Name;
        }

        public string GetHairType()
        {
            return _hair.GetType().Name;
        }

        public virtual string GetEspecialProps()
        {
            return "Special";
        }
    }
}
