﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_4;
using System.Collections.Generic;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void TestMethod1()
        {
            string str = "somebody once told me the world is gonna roll me";

            Dictionary<char, int> dict = Program.CalcLetters(str);


            Assert.IsTrue(dict.ContainsKey('o'));

        }

        [TestMethod]
        public void TestMethod2()
        {
            string str = "somebody once told me the world is gonna roll me";

            Dictionary<char, int> dict = Program.CalcLetters(str);

            Assert.IsTrue(!dict.ContainsKey(','));
            Assert.IsTrue(!dict.ContainsKey('.'));
            Assert.IsTrue(!dict.ContainsKey('!'));
            Assert.IsTrue(!dict.ContainsKey(' '));
        }

        [TestMethod]
        public void TestMethod3()
        {
            string str = "в тридевятом царстве, в тридесятом государстве";

            Dictionary<char, int> dict = Program.CalcLetters(str);

            Assert.AreEqual(dict['и'], 2);
            Assert.AreEqual(dict['я'], 2);
        }

        [TestMethod]
        public void TestMethod4()
        {
            string str = "В тридевятом царстве, в тридесятом государстве";

            Dictionary<char, int> dict = Program.CalcLetters(str);

            Assert.AreEqual(dict['и'], 2);
            Assert.AreEqual(dict['я'], 2);

            Assert.IsTrue(!dict.ContainsKey(','));
            Assert.IsTrue(!dict.ContainsKey('.'));
            Assert.IsTrue(!dict.ContainsKey('!'));
            Assert.IsTrue(!dict.ContainsKey(' '));
        }

        [TestMethod]
        public void TestMethod5()
        {
            string str = "ччччч ччччч чч";

            Dictionary<char, int> dict = Program.CalcLetters(str);

            Assert.AreEqual(dict['ч'], 12);
        }

        [TestMethod]
        public void TestMethod7()
        {
            string str = "ЯяяяЯяяяЯ";

            Dictionary<char, int> dict = Program.CalcLetters(str);

            Assert.AreEqual(dict['я'], 9);
        }


        [TestMethod]
        public void TestMethod6()
        {
            string str = "    ";

            Dictionary<char, int> dict = Program.CalcLetters(str);

            Assert.IsTrue(!dict.ContainsKey(' '));
        }
    }
}
