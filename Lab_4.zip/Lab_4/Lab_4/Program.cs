﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_4
{
    public class Program
    {
        public static string Letters = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
        public static Random Rnd = new Random();

        static void Main(string[] args)
        {
            Task2();
        }

        public static void Task2()
        {
            Console.Write("Введите количество предложений: ");

            int sentencesAmount = int.Parse(Console.ReadLine());

            Console.Write("Введите количество слов: ");

            int wordsAmount = int.Parse(Console.ReadLine());

            string text = GenText(sentencesAmount, wordsAmount);


            Console.WriteLine(text);

            Console.ReadKey();
        }

        public static string GenDate()
        {
            StringBuilder date = new StringBuilder();

            int dateFormat = Rnd.Next(1, 4);

            int year = Rnd.Next(8, 12);
            int month, day = 0;

            switch (year)
            {
                case 8:
                    month = Rnd.Next(8, 13);
                    break;
                case 11:
                    month = Rnd.Next(1, 10);
                    break;
                default:
                    month = Rnd.Next(1, 13);
                    break;
            }

            switch (month)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 9:
                case 12:
                    day = Rnd.Next(1, 32);
                    break;
                case 2:
                    day = Rnd.Next(1, 29);
                    break;
                case 4:
                case 6:
                case 10:
                case 11:
                    day = Rnd.Next(1, 31);
                    break;
            }

            switch (dateFormat)
            {
                case 1:
                    date.AppendFormat("{0:D2}.{1:D2}.{2:D2}", day, month, year);
                    break;
                case 2:
                    date.AppendFormat("{0:D2}/{1:D2}/{2:D2}", day, month, year);
                    break;
                case 3:
                    date.AppendFormat("{0:D2}.{1:D2}.{2:D4}", day, month, year);
                    break;
            }

            return date.ToString();
        }

        public static string GenText(int sentencesAmount, int wordsAmount)
        {
            StringBuilder text = new StringBuilder(sentencesAmount);

            for (int i = 0; i < sentencesAmount; i++)
            {
                text.Append(GenSentence(wordsAmount));
            }

            return text.ToString();
        }

        public static string GenWord(int letterAmount)
        {
            StringBuilder word = new StringBuilder(letterAmount);

            if (Rnd.Next(1, 10) <= 3)
            {
                return GenDate();
            }

            char letter;

            for (int i = 0; i < letterAmount; i++)
            {

                letter = Letters[Rnd.Next(0, 33)];

                word.Append(letter);
            }

            return word.ToString();
        }

        public static string GenSentence(int wordsAmount)
        {
            StringBuilder sentence = new StringBuilder();

            for (int i = 0; i < wordsAmount - 1; i++)
            {
                sentence.Append(GenWord(Rnd.Next(1, 15)) + " ");
            }

            sentence.Append(GenWord(Rnd.Next(1, 15)));

            switch (Rnd.Next(1, 3))
            {
                case 1:
                    sentence.Append("?");
                    break;
                case 2:
                    sentence.Append(".");
                    break;
                case 3:
                    sentence.Append("!");
                    break;
            }
            return sentence.ToString();
        }

        public static Dictionary<char, int> CalcLetters(string str)
        {
            Dictionary<char, int> lettersInWordAmount = new Dictionary<char, int>();

            foreach (char letter in str)
            {
                if (Char.IsPunctuation(letter) || letter == ' ')
                {
                    continue;
                }

                if (!lettersInWordAmount.ContainsKey(Char.ToLower(letter)))
                {
                    lettersInWordAmount.Add(Char.ToLower(letter), 0);
                }

                lettersInWordAmount[Char.ToLower(letter)]++;
            }

            return lettersInWordAmount;
        }
        public static void Task1()
        {
            Console.Write("Введите строку не более 200 символов:");

            string enteredString = Console.ReadLine();
            Dictionary<char, int> lettersInWordAmount = CalcLetters(enteredString);


            string amountCase = "", letterAsNumber;
            char lastDigit;


            foreach (KeyValuePair<char, int> letter in lettersInWordAmount)
            {
                letterAsNumber = letter.Value.ToString();

                lastDigit = letterAsNumber[letterAsNumber.Length - 1];

                switch (lastDigit)
                {
                    case '0':
                    case '1':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        amountCase = "раз";
                        break;
                    case '2':
                    case '3':
                    case '4':
                        amountCase = "раза";
                        break;
                }

                Console.WriteLine("Буква {0} встречается {1} {2}!", letter.Key, letter.Value, amountCase);
            }

            Console.ReadKey();
        }
    }
}
