﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lab_9_classes;

namespace Lab_9
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private Lab_9_classes.Matrix m1, m2, m3;

        private void MultipleMatricesBtn_Click(object sender, RoutedEventArgs e)
        {
            double[,] m1Elements, m2Elements;
            int rows1, columns1, rows2, columns2;

            string[] vals1, vals2;

            if (Matrix1TextBox.LineCount == 0 || Matrix2TextBox.LineCount == 0)
            {
                MessageBox.Show("Матрицы не могут быть пустыми!");
                return;
            }

            rows1 = Matrix1TextBox.LineCount;
            columns1 = Matrix1TextBox.GetLineText(0).Trim().Split(' ').Length;

            rows2 = Matrix2TextBox.LineCount;
            columns2 = Matrix2TextBox.GetLineText(0).Trim().Split(' ').Length;

            m1Elements = new double[rows1, columns1];
            m2Elements = new double[rows2, columns2];

            int i, j;
            double t;

            for (i = 0; i < Matrix1TextBox.LineCount; i++)
            {
                vals1 = Matrix1TextBox.GetLineText(i).Trim().Split(' ');

                if (vals1.Length != columns1)
                {
                    MessageBox.Show("Количество столбцов должно быть постоянным!");
                    return;
                }

                for (j = 0; j < vals1.Length; j++)
                {
                    if (!double.TryParse(vals1[j], out t))
                    {
                        MessageBox.Show("Элемент матрицы должен быть числом!");
                        return;
                    }

                    m1Elements[i, j] = double.Parse(vals1[j]);
                }
            }

            for (i = 0; i < Matrix2TextBox.LineCount; i++)
            {
                vals2 = Matrix2TextBox.GetLineText(i).Trim().Split(' ');

                if (vals2.Length != columns2)
                {
                    MessageBox.Show("Количество столбцов должно быть постоянным!");
                    return;
                }

                for (j = 0; j < vals2.Length; j++)
                {
                    if (!double.TryParse(vals2[j], out t))
                    {
                        MessageBox.Show("Элемент матрицы должен быть числом!");
                        return;
                    }

                    m2Elements[i, j] = double.Parse(vals2[j]);
                }
            }

            string line;

            try
            {
                m1 = new Lab_9_classes.Matrix(rows1, columns1);
                m2 = new Lab_9_classes.Matrix(rows2, columns2);

                m1.Fill(m1Elements);
                m2.Fill(m2Elements);

                m3 = m1 * m2;

                MatrixResultTextBox.Text = "";
             
                for (i = 0; i < m3.Elements.GetLength(0); i++)
                {
                    line = "";

                    for (j = 0; j < m3.Elements.GetLength(1); j++)
                    {
                        line += m3.Elements[i, j].ToString() + " ";
                    }

                    MatrixResultTextBox.AppendText(line + "\n");
                }
            }
            catch (MatrixInvalidArgException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (MatrixMultipleException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
