﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_9_classes
{
    public class MatrixInvalidArgException : Exception
    {
        public MatrixInvalidArgException(string message) : base(message)
        {

        }
    }
}
