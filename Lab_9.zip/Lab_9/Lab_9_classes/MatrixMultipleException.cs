﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_9_classes
{
    public class MatrixMultipleException : Exception
    {
        public MatrixMultipleException(string message) : base(message)
        {

        }
    }
}
