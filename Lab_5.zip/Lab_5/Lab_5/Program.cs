﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_5
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Введите арифметическое выражение: ");

            string expression = Console.ReadLine();
            double? result = Exprsn.Calc(expression);

            Console.Write("Результат выражения: ");

            if (result != null)
            {
                Console.Write(result);
            }
            else
            {
                Console.Write("Ошибка при вычисление(Вы неправильно ввели строку)!");
            }

            Console.ReadKey();
        }
    }
}
