﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lab_5
{
    public class Exprsn
    {
        public static double? Calc(string expression)
        {
            RegEx regexHigh = new RegEx(@"\s*-*\d+(,\d+)*\s*(?<operand>[\*:]{1})\s*-*\d+(,\d+)*\s*");
            RegEx regexLow = new RegEx(@"\s*-*\d+(,\d+)*\s*(?<operand>[\+-]{1})\s*-*\d+(,\d+)*\s*");

            expression = CalcExpr(regexHigh, expression, "*", ":");
            expression = CalcExpr(regexLow, expression, "-", "+");

            if (double.TryParse(expression, out var n))
            {
                return double.Parse(expression);
            }
            else
            {
                return null;
            }
        }
        public static string CalcExpr(Regex exps, string expression, string op1, string op2)
        {
            Match operandMatch;
            double number1, number2, result = 0;
            int operandPos;
            string operandAsStr;

            operandMatch = exps.Match(expression);

            while (operandMatch.Success)
            {
                number1 = Convert.ToDouble(expression.Substring(operandMatch.Index, operandMatch.Groups["operand"].Index - operandMatch.Index));
                number2 = Convert.ToDouble(expression.Substring(operandMatch.Groups["operand"].Index + 1, operandMatch.Index + operandMatch.Value.Length - 1 - operandMatch.Groups["operand"].Index));


                if (operandMatch.Groups["operand"].Value.Trim() == "*")
                {
                    result = number1 * number2;
                }
                else if (operandMatch.Groups["operand"].Value.Trim() == ":")
                {
                    result = number1 / number2;
                }
                else if (operandMatch.Groups["operand"].Value.Trim() == "-")
                {
                    result = number1 - number2;
                }
                else if (operandMatch.Groups["operand"].Value.Trim() == "+")
                {
                    result = number1 + number2;
                }

                expression = expression.Substring(0, operandMatch.Index) + result.ToString() + expression.Substring(operandMatch.Index + operandMatch.Value.Length);

                operandMatch = exps.Match(expression);
            }

            return expression;
        }
    }
}
