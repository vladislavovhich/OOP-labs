﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_5;
namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test1()
        {
            double? result = Exprsn.Calc("10 + 2 + 3 + 4 + 5");

            Assert.AreEqual(result, 24);
        }

        [TestMethod]
        public void Test2()
        {
            double? result = Exprsn.Calc("2 * 2 * 2 * 2 * 2");

            Assert.AreEqual(result, 32);
        }

        [TestMethod]
        public void Test3()
        {
            double? result = Exprsn.Calc("2*   -2 * 2* -2    * 2");

            Assert.AreEqual(result, 32);
        }

        [TestMethod]
        public void Test4()
        {
            double? result = Exprsn.Calc("-2 - 5");

            Assert.AreEqual(result, -7);
        }

        [TestMethod]
        public void Test5()
        {
            double? result = Exprsn.Calc("-2 - -5");

            Assert.AreEqual(result, 3);
        }

        [TestMethod]
        public void Test6()
        {
            double? result = Exprsn.Calc("-2--5");

            Assert.AreEqual(result, 3);
        }

        [TestMethod]
        public void Test7()
        {
            double? result = Exprsn.Calc("-2-::---5");

            Assert.AreEqual(result, null);
        }

        [TestMethod]
        public void Test8()
        {
            double? result = Exprsn.Calc("-2-**::--5 + abc");

            Assert.AreEqual(result, null);
        }

        [TestMethod]
        public void Test9()
        {
            double? result = Exprsn.Calc("abc + zdef : 2");

            Assert.AreEqual(result, null);
        }

    }
}
